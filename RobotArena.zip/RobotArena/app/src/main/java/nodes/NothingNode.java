package nodes;

public class NothingNode extends Node {

    public NothingNode(BlockType type) {
        super(type);
    }

    public String toString() {
        return "Nothing";
    }

}
